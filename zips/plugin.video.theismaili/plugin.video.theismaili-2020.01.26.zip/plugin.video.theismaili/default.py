# -*- coding: utf-8 -*-
import urllib
import urlparse
import sys
import requests
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui

#httpJsonHeaders = {'Accept': 'application/json;pk=BCpkADawqM3ZqIjfoCpdhXGILJT854nH8ULODob_IGTzimJ1fZPPRlAOqJ-YTzLVY0QSpO6VyJcxMdfXY2fBiThjUyQYoKWl3JyO4DIwj5d7dVaxjNO92WFtFTY'}

qp = urllib.quote_plus
uqp = urllib.unquote_plus

url = 'https://the.ismaili/video-list-api?page=0'
#src = 'https://edge.api.brightcove.com/playback/v1/accounts/648715333001/videos/%s'

sysaddon = sys.argv[0]
syshandle = int(sys.argv[1])


def addDir(name, mode, url=None, thumb=None, fanart=None, videoInfo=None, cm=None, isFolder=True):
    # xbmc.log("%s,%s,%s,%s,%s" % (name, url, thumb, fanart, videoInfo), level=xbmc.LOGNOTICE)
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': thumb, 'fanart': fanart})
    liz.setInfo('Video', videoInfo)
    if cm != None:
        liz.addContextMenuItems(cm)
    if not isFolder:
        liz.setProperty('IsPlayable', 'true')
    u = '%s?mode=%s' % (sysaddon, mode)
    if url != None:
        u = u + '&url=%s' % qp(url)
    # ok=xbmcplugin.addDirectoryItem(handle=syshandle,url=u,listitem=liz,isFolder=True)
    xbmc.log('URL: %s' % (u), level=xbmc.LOGDEBUG)
    ilist = xbmcplugin.addDirectoryItem(handle=syshandle, url=u, listitem=liz, isFolder=isFolder)
    # ilist.append
    return(ilist)


def getVideo(url):
    liz = xbmcgui.ListItem(path=url)
    # xbmc.log("getRequest URL:%s" % str(url), level=xbmc.LOGNOTICE)
    xbmcplugin.setResolvedUrl(syshandle, True, liz)


def HOME(url):
    xbmc.log("URL:%s" % url, level=xbmc.LOGNOTICE)
    html = requests.get(url).json()
    pagination = True
    if len(html) >= 26:
        pagination = False
    # xbmc.log("Length:%s" % len(html), level=xbmc.LOGNOTICE)
    # xbmc.log("pagination:%s" % pagination, level=xbmc.LOGNOTICE)
    for i in html:
        # r=requests.get()
        try:
            #r = requests.get(src % i["Brightcove Video Id"], headers=httpJsonHeaders)
            #xbmc.log("Request Json:%s" % (r.json()), level=xbmc.LOGDEBUG)
            #b = r.json()
            #if r.status_code == 200:
                name = i["title"].replace("Video:", "").strip()
                desc = i['Summary']
                #thumb = i["poster"].split('?', 1)[0]
                thumb = i["Image"]['src']
                fanart = thumb
                #duration = int(b['duration']) / 1000
                #vsrc = [u["src"] for u in b["sources"] if u["src"].startswith("https") and u["container"] == 'M2TS'][0]
                vsrc = i['Youtube/Vimeo'].split('=')[1]
                src = "plugin://plugin.video.youtube/play/?video_id="+vsrc
                infoList = {}
                infoList['TVShowTitle'] = name
                infoList['Title'] = name
                #infoList['Duration'] = duration
                infoList['Studio'] = 'The Ismaili'
                infoList['Plot'] = desc
                infoList['MPAA'] = 'TV-PG'
                infoList['mediatype'] = 'episode'
                addDir(name, 'GV', src, thumb, fanart, infoList, isFolder=False)
        except:
            pass
    while pagination:
        op = url[-1]
        np = str(int(op) + 1)
        purl = url.replace(op, np)
        addDir("Next Page", 'GL', purl, isFolder=True)
        return


params = dict(urlparse.parse_qsl(sys.argv[2].replace('?', '')))
xbmc.log("Parameter:%s" % (params), level=xbmc.LOGNOTICE)
mode = 'GL'
try:
    mode = params["mode"]
except:
    pass
try:
    url = uqp(params["url"])
except:
    pass

if mode == 'GL':
    HOME(url)
# elif mode == 'NP':
    # HOME(url)
elif mode == 'GV':
    getVideo(url)
xbmcplugin.setContent(syshandle, 'episodes')
xbmcplugin.addSortMethod(syshandle, xbmcplugin.SORT_METHOD_UNSORTED)
xbmcplugin.addSortMethod(syshandle, xbmcplugin.SORT_METHOD_TITLE)
xbmcplugin.addSortMethod(syshandle, xbmcplugin.SORT_METHOD_EPISODE)
xbmcplugin.endOfDirectory(syshandle, cacheToDisc=True)
