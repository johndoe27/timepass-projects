'''
Created on Dec 24, 2011

@author: ajju
'''
from xoze.snapvideo import VideoHost, Video, STREAM_QUAL_SD
from xoze.utils import http, encoders
import re
import BeautifulSoup
import urllib
VIDEO_HOSTING_NAME = 'WatchShare'


def getVideoHost():
    video_host = VideoHost()
    video_host.set_icon('https://watchshare.net/wp-content/uploads/2019/06/watch-vid.png')
    video_host.set_name(VIDEO_HOSTING_NAME)
    return video_host

 
def retrieveVideoInfo(video_id):
      
    video = Video()
    video.set_video_host(getVideoHost())
    video.set_id(video_id)
    try:
        video_info_link = 'https://watchshare.net/embed/' + str(video_id)
        html = BeautifulSoup.BeautifulSoup(http.HttpClient().get_html_content(url=video_info_link)).findAll('video',{'id':'content_video'})[0]
        final_video_link = ''
        try:
            video_link = html.source.get('src')
            img_link = html.get('poster')
            video.set_thumb_image(img_link)
        except:
            pass

        video.set_stopped(False)
        video.add_stream_link(STREAM_QUAL_SD, video_link)
          
    except: 
        video.set_stopped(True)
    return video