'''
Created on Dec 24, 2011

@author: ajju
'''
from xoze.snapvideo import VideoHost, Video, STREAM_QUAL_SD
from xoze.utils import http, encoders
import re
try:
    import resolveurl  # @UnresolvedImport
except:
    import xoze.alternatives.urlresolverdummy as resolveurl
VIDEO_HOSTING_NAME = 'FlashPlayer'

def getVideoHost():
    video_host = VideoHost()
    video_host.set_icon('https://i.imgur.com/CAwE87J.jpg?1')
    video_host.set_name(VIDEO_HOSTING_NAME)
    return video_host

def retrieveVideoInfo(video_id):
    
    video = Video()
    video.set_video_host(getVideoHost())
    video.set_id(video_id)
    try:
        video_info_link = 'flash.business-loan.ltd/public/dist/index10.html?id=' + str(video_id)
        sources = []
        hosted_media = resolveurl.HostedMediaFile(url=video_info_link)
        sources.append(hosted_media)
        source = resolveurl.choose_source(sources)
        stream_url = ''
        if source: 
            stream_url = source.resolve()
        final_video_link = stream_url

        video.set_stopped(False)
        video.add_stream_link(STREAM_QUAL_SD, final_video_link)
        
    except: 
        video.set_stopped(True)
    return video