'''
Created on Nov 21, 2012

@author: ajju
'''
from xoze.snapvideo import VideoHost, Video, STREAM_QUAL_HD_720
from xoze.utils import http
import logging
import re
try:
    import resolveurl  # @UnresolvedImport
except:
    import xoze.alternatives.urlresolverdummy as resolveurl

VIDEO_HOSTING_NAME = 'TVlogy'

def getVideoHost():
    video_host = VideoHost()
    video_host.set_icon('http://i.imgur.com/BQ75a3I.jpg')
    video_host.set_name(VIDEO_HOSTING_NAME)
    return video_host

def retrieveVideoInfo(video_id):
    
    video_info = Video()
    video_info.set_video_host(getVideoHost())
    video_info.set_id(video_id)
    videoUrl = 'flash.business-loan.ltd/public/dist/tvlogy10.html?id=' + str(video_id)

    
    sources = []
    hosted_media = resolveurl.HostedMediaFile(url=videoUrl)
    sources.append(hosted_media)
    source = resolveurl.choose_source(sources)
    stream_url = ''
    if source: 
        stream_url = source.resolve()

    video_info.set_stopped(False)
    video_info.set_thumb_image('')
    video_info.set_name(' ')
    video_info.add_stream_link(STREAM_QUAL_HD_720, stream_url)
    return video_info


